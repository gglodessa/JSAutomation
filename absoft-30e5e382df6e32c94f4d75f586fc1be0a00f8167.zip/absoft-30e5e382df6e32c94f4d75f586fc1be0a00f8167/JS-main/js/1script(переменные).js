"use strict";

let number = 5; // изменяемая
const leftBorderWidth = 1; //постоянная или прямая 

number = 10
console.log(number);

const obj = {
    a: 50
};
obj.a =10;
console.log(obj); // прямых не бывает вот как обойти можно


console.log(name);
var name = 'Alex'; // вар используется до того как она еще была объявлена и это ошибка

{
let result = 50;
}
console.log(result); // нет доступа к переменной если в скобках

