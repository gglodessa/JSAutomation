"use strict";

const category = 'toys';
//console.log('https;//google.ru/' + category + '/' + '4'); //так не красиво
console.log(`https;//google.ru/${category}/5`); //так красиво))))

const user ='Alex';
alert(`привет, ${user}`);