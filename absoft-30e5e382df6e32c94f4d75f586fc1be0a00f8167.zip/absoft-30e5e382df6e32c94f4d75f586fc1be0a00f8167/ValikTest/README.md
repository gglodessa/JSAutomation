Руководство к запуску тестов:

clone / download the repository

npm install

npm install selenium-webdriver

npm install chai

npm i node-fetch --save

for run test1: node test1

for run test2: node test2

for run test3: node test3

for run test4: node test4
